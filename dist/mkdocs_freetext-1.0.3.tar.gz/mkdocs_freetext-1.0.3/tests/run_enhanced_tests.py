"""
Test runner for the enhanced MkDocs Free-Text Plugin functionality.

This script runs all tests related to the improvements made to the plugin,
including triple quote support, JavaScript auto-fix, and DOM verification.
"""

import sys
import os
import subprocess
import json
from pathlib import Path


def run_tests():
    """Run all enhanced functionality tests."""
    
    # Get the base path
    base_path = Path(__file__).parent
    mkdocs_path = base_path / ".."
    
    print("🚀 Running Enhanced MkDocs Free-Text Plugin Tests")
    print("=" * 60)
    
    # Test results
    test_results = {
        "total_tests": 0,
        "passed": 0,
        "failed": 0,
        "errors": []
    }
    
    # Test files to run
    test_files = [
        "test_enhanced_functionality.py",
        "test_html_validation.py"
    ]
    
    for test_file in test_files:
        test_path = base_path / test_file
        
        if not test_path.exists():
            print(f"❌ Test file not found: {test_file}")
            test_results["errors"].append(f"Missing test file: {test_file}")
            continue
        
        print(f"\n📋 Running {test_file}...")
        print("-" * 40)
        
        try:
            # Run with Python's unittest module since pytest might not be available
            result = subprocess.run([
                sys.executable, "-m", "unittest", 
                f"tests.{test_file[:-3]}", "-v"
            ], 
            cwd=mkdocs_path,
            capture_output=True, 
            text=True, 
            timeout=60
            )
            
            if result.returncode == 0:
                print(f"✅ {test_file} - All tests passed")
                test_results["passed"] += 1
            else:
                print(f"❌ {test_file} - Some tests failed")
                print("STDOUT:", result.stdout)
                print("STDERR:", result.stderr)
                test_results["failed"] += 1
                test_results["errors"].append(f"{test_file}: {result.stderr}")
            
            test_results["total_tests"] += 1
            
        except subprocess.TimeoutExpired:
            print(f"⏰ {test_file} - Test timed out")
            test_results["failed"] += 1
            test_results["errors"].append(f"{test_file}: Timeout")
        except Exception as e:
            print(f"💥 {test_file} - Error running tests: {e}")
            test_results["failed"] += 1
            test_results["errors"].append(f"{test_file}: {str(e)}")
    
    # Run manual validation tests
    print(f"\n🔍 Running Manual Validation Tests...")
    print("-" * 40)
    
    manual_tests = run_manual_validation_tests()
    test_results.update(manual_tests)
    
    # Print summary
    print(f"\n📊 Test Summary")
    print("=" * 30)
    print(f"Total Test Suites: {test_results['total_tests']}")
    print(f"Passed: {test_results['passed']}")
    print(f"Failed: {test_results['failed']}")
    
    if test_results["errors"]:
        print(f"\n❌ Errors:")
        for error in test_results["errors"]:
            print(f"  - {error}")
    
    # Return success/failure
    return test_results["failed"] == 0


def run_manual_validation_tests():
    """Run manual validation tests that don't require pytest."""
    
    results = {"manual_passed": 0, "manual_failed": 0}
    
    try:
        # Test 1: Verify HTML files exist
        base_path = Path(__file__).parent / ".." / "documentation" / "site" / "demo"
        current_html = base_path / "index.html"
        backup_html = base_path / "index.html.backup"
        
        if current_html.exists() and backup_html.exists():
            print("✅ HTML files found")
            results["manual_passed"] += 1
        else:
            print("❌ HTML files missing")
            results["manual_failed"] += 1
        
        # Test 2: Verify JavaScript improvements are present
        if current_html.exists():
            with open(current_html, 'r', encoding='utf-8') as f:
                content = f.read()
            
            improvements = [
                "function initAutoFix()",
                "removeEventListener('input'",
                "console.log('✅",
                "ℹ️ autoSave function not implemented"
            ]
            
            all_present = all(improvement in content for improvement in improvements)
            
            if all_present:
                print("✅ JavaScript improvements detected")
                results["manual_passed"] += 1
            else:
                print("❌ Some JavaScript improvements missing")
                results["manual_failed"] += 1
        
        # Test 3: Verify triple quote support in plugin
        plugin_path = Path(__file__).parent / ".." / "mkdocs_freetext" / "plugin.py"
        
        if plugin_path.exists():
            with open(plugin_path, 'r', encoding='utf-8') as f:
                plugin_content = f.read()
            
            if "_parse_comma_separated_config" in plugin_content and '"""' in plugin_content:
                print("✅ Triple quote support detected in plugin")
                results["manual_passed"] += 1
            else:
                print("❌ Triple quote support missing in plugin")
                results["manual_failed"] += 1
        else:
            print("❌ Plugin file not found")
            results["manual_failed"] += 1
        
        # Test 4: Verify no critical JavaScript errors
        if current_html.exists():
            with open(current_html, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Check for problematic patterns that would cause JS errors
            problematic_patterns = [
                "❌ autoSave function not found for",
                "Identifier 'savedAnswer' has already been declared"
            ]
            
            has_problems = any(pattern in content for pattern in problematic_patterns)
            
            if not has_problems:
                print("✅ No critical JavaScript errors detected")
                results["manual_passed"] += 1
            else:
                print("❌ Critical JavaScript errors detected")
                results["manual_failed"] += 1
    
    except Exception as e:
        print(f"💥 Error in manual validation: {e}")
        results["manual_failed"] += 1
    
    return results


def validate_plugin_functionality():
    """Validate that the plugin can be imported and has expected methods."""
    
    try:
        sys.path.insert(0, str(Path(__file__).parent / ".."))
        
        from mkdocs_freetext.plugin import FreetextPlugin
        
        plugin = FreetextPlugin()
        
        # Test that expected methods exist
        expected_methods = [
            'on_page_content',
            '_parse_comma_separated_config'
        ]
        
        missing_methods = []
        for method in expected_methods:
            if not hasattr(plugin, method):
                missing_methods.append(method)
        
        if not missing_methods:
            print("✅ Plugin imports successfully and has expected methods")
            return True
        else:
            print(f"❌ Plugin missing methods: {missing_methods}")
            return False
            
    except ImportError as e:
        print(f"❌ Plugin import failed: {e}")
        return False
    except Exception as e:
        print(f"💥 Plugin validation error: {e}")
        return False


if __name__ == "__main__":
    print("Starting test validation...")
    
    # Run plugin validation first
    plugin_ok = validate_plugin_functionality()
    
    if plugin_ok:
        success = run_tests()
        exit_code = 0 if success else 1
    else:
        print("❌ Plugin validation failed, skipping tests")
        exit_code = 1
    
    print(f"\nTest run completed with exit code: {exit_code}")
    sys.exit(exit_code)
