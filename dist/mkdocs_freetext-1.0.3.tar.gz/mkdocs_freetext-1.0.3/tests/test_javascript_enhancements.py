"""
Integration test for the enhanced JavaScript functionality in the demo HTML.

This test validates that all the JavaScript improvements are properly
implemented and functioning correctly.
"""

import os
import re
from pathlib import Path


def load_html_files():
    """Load current and backup HTML files."""
    base_path = Path(__file__).parent / ".." / "documentation" / "site" / "demo"
    
    current_path = base_path / "index.html"
    backup_path = base_path / "index.html.backup"
    
    if not current_path.exists():
        raise FileNotFoundError(f"Current HTML file not found: {current_path}")
    
    if not backup_path.exists():
        raise FileNotFoundError(f"Backup HTML file not found: {backup_path}")
    
    with open(current_path, 'r', encoding='utf-8') as f:
        current_html = f.read()
    
    with open(backup_path, 'r', encoding='utf-8') as f:
        backup_html = f.read()
    
    return current_html, backup_html


def test_auto_fix_function_exists():
    """Test that the initAutoFix function exists and is properly structured."""
    current_html, backup_html = load_html_files()
    
    # Should exist in current but not backup
    assert "function initAutoFix()" in current_html
    assert "function initAutoFix()" not in backup_html
    
    # Should have proper structure
    auto_fix_pattern = r"function initAutoFix\(\)\s*\{.*?\}"
    match = re.search(auto_fix_pattern, current_html, re.DOTALL)
    assert match is not None, "initAutoFix function not properly structured"
    
    print("✅ initAutoFix function exists and is properly structured")


def test_event_listener_improvements():
    """Test that event listener improvements are implemented."""
    current_html, backup_html = load_html_files()
    
    # Should have DOM ready event listener
    assert "document.addEventListener('DOMContentLoaded', initAutoFix)" in current_html
    
    # Should have immediate execution
    assert "initAutoFix();" in current_html
    
    # Should remove existing event listeners before adding new ones
    assert "removeEventListener('input'" in current_html
    
    print("✅ Event listener improvements implemented")


def test_console_logging_comprehensive():
    """Test that comprehensive console logging is implemented."""
    current_html, backup_html = load_html_files()
    
    # Should have various types of logging
    logging_indicators = ["console.log('✅", "console.log('ℹ️", "console.warn('❌"]
    
    for indicator in logging_indicators:
        assert indicator in current_html, f"Missing logging indicator: {indicator}"
    
    # Should have detailed function checking logs
    assert "Functions found for" in current_html
    
    print("✅ Comprehensive console logging implemented")


def test_auto_save_handling_fixed():
    """Test that autoSave function handling was fixed."""
    current_html, backup_html = load_html_files()
    
    # Should have informational message instead of error
    assert "ℹ️ autoSave function not implemented" in current_html
    
    # Should NOT have the old error message
    assert "❌ autoSave function not found for" not in current_html
    
    # Should check for autoSave existence before removing listener
    assert "if (autoSaveFunc)" in current_html
    
    print("✅ AutoSave function handling fixed")


def test_character_count_functions():
    """Test that character count functions are properly generated."""
    current_html, backup_html = load_html_files()
    
    # Should have updateCharCount functions with question IDs
    pattern = r"function updateCharCount_([a-f0-9]+)\(\)"
    matches = re.findall(pattern, current_html)
    
    assert len(matches) > 0, "No updateCharCount functions found"
    
    # Each function should have proper structure
    for question_id in matches:
        func_content_pattern = rf"function updateCharCount_{question_id}\(\).*?textarea\.value\.length.*?\}}"
        assert re.search(func_content_pattern, current_html, re.DOTALL), f"updateCharCount_{question_id} missing proper implementation"
    
    print(f"✅ {len(matches)} character count functions properly implemented")


def test_submit_answer_functions():
    """Test that submit answer functions are properly generated."""
    current_html, backup_html = load_html_files()
    
    # Should have submitAnswer functions
    pattern = r"function submitAnswer_([a-f0-9]+)\(\)"
    matches = re.findall(pattern, current_html)
    
    assert len(matches) > 0, "No submitAnswer functions found"
    
    # Each function should have proper structure
    for question_id in matches:
        func_content_pattern = rf"function submitAnswer_{question_id}\(\).*?feedbackElement.*?\}}"
        assert re.search(func_content_pattern, current_html, re.DOTALL), f"submitAnswer_{question_id} missing proper implementation"
    
    print(f"✅ {len(matches)} submit answer functions properly implemented")


def test_dom_verification_mechanism():
    """Test that DOM verification mechanism is implemented."""
    current_html, backup_html = load_html_files()
    
    # Should have setTimeout verification
    assert "setTimeout(function()" in current_html
    
    # Should verify textContent persistence with 10ms timeout
    verification_pattern = r"setTimeout\(function\(\).*?textContent.*?\}, 10\)"
    assert re.search(verification_pattern, current_html, re.DOTALL), "DOM verification mechanism not found"
    
    print("✅ DOM verification mechanism implemented")


def test_javascript_syntax_errors_fixed():
    """Test that JavaScript syntax errors have been resolved."""
    current_html, backup_html = load_html_files()
    
    # Should not have problematic patterns that cause JS errors
    problematic_patterns = [
        "Identifier 'savedAnswer' has already been declared",
        "❌ autoSave function not found for"
    ]
    
    for pattern in problematic_patterns:
        assert pattern not in current_html, f"Problematic pattern still exists: {pattern}"
    
    print("✅ JavaScript syntax errors fixed")


def test_question_structure_integrity():
    """Test that question structure is intact."""
    current_html, backup_html = load_html_files()
    
    # Extract question IDs from both files
    pattern = r'data-question-id="([^"]+)"'
    
    current_questions = set(re.findall(pattern, current_html))
    backup_questions = set(re.findall(pattern, backup_html))
    
    # Should have same questions
    assert current_questions == backup_questions, "Question structure changed"
    assert len(current_questions) > 0, "No questions found"
    
    print(f"✅ Question structure integrity maintained ({len(current_questions)} questions)")


def test_new_features_not_in_backup():
    """Test that new features are not present in backup."""
    current_html, backup_html = load_html_files()
    
    new_features = [
        "function initAutoFix()",
        "removeEventListener('input'",
        "console.log('✅",
        "setTimeout(function()",
        "ℹ️ autoSave function not implemented"
    ]
    
    for feature in new_features:
        assert feature in current_html, f"New feature missing: {feature}"
        assert feature not in backup_html, f"Feature should not be in backup: {feature}"
    
    print("✅ All new features properly added")


def run_all_javascript_tests():
    """Run all JavaScript and HTML validation tests."""
    print("🚀 Running JavaScript & HTML Enhancement Tests")
    print("=" * 55)
    
    test_functions = [
        test_auto_fix_function_exists,
        test_event_listener_improvements, 
        test_console_logging_comprehensive,
        test_auto_save_handling_fixed,
        test_character_count_functions,
        test_submit_answer_functions,
        test_dom_verification_mechanism,
        test_javascript_syntax_errors_fixed,
        test_question_structure_integrity,
        test_new_features_not_in_backup
    ]
    
    passed = 0
    failed = 0
    
    for test_func in test_functions:
        try:
            test_func()
            passed += 1
        except Exception as e:
            print(f"❌ {test_func.__name__} failed: {e}")
            failed += 1
    
    print("\n" + "=" * 55)
    print(f"📊 Test Results: {passed} passed, {failed} failed")
    
    if failed == 0:
        print("🎉 All JavaScript & HTML enhancement tests passed!")
        return True
    else:
        print(f"💥 {failed} tests failed")
        return False


if __name__ == "__main__":
    success = run_all_javascript_tests()
    exit_code = 0 if success else 1
    print(f"\nExiting with code: {exit_code}")
    exit(exit_code)
