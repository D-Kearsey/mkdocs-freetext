"""
Test suite for submit button improvements using pytest structure.
Validates that the generated HTML contains the correct JavaScript enhancements.
"""

import os
import re
import pytest
from pathlib import Path


class TestSubmitButtonImprovements:
    """Test suite for submit button improvements."""
    
    def setup_method(self):
        """Set up test environment."""
        base_path = Path(__file__).parent / ".."
        
        # Look for test site in multiple possible locations
        possible_paths = [
            base_path / "test-site" / "site" / "index.html",
            base_path / "documentation" / "site" / "demo" / "index.html",
            "test-site/site/index.html",
            "documentation/site/demo/index.html"
        ]
        
        self.test_site_path = None
        for path in possible_paths:
            if Path(path).exists():
                self.test_site_path = str(path)
                break
        
        if not self.test_site_path:
            pytest.skip("No test site found in expected locations")
    
    def test_submit_button_text_change(self):
        """Test that submit button text changes to 'Submitted'."""
        with open(self.test_site_path, 'r', encoding='utf-8') as f:
            html_content = f.read()
        
        button_text_change = "submitBtn.textContent = 'Submitted';"
        assert button_text_change in html_content, "Button text change to 'Submitted' not found"
    
    def test_submit_button_tooltip(self):
        """Test that submit button gets tooltip 'Click to resubmit'."""
        with open(self.test_site_path, 'r', encoding='utf-8') as f:
            html_content = f.read()
        
        tooltip_addition = "submitBtn.title = 'Click to resubmit';"
        assert tooltip_addition in html_content, "Tooltip 'Click to resubmit' not found"
    
    def test_success_message_removed(self):
        """Test that generic success message is removed."""
        with open(self.test_site_path, 'r', encoding='utf-8') as f:
            html_content = f.read()
        
        success_message = "Answer submitted successfully!"
        assert success_message not in html_content, "Success message should be removed"
    
    def test_button_state_restoration(self):
        """Test that button state restoration logic is present."""
        with open(self.test_site_path, 'r', encoding='utf-8') as f:
            html_content = f.read()
        
        # Check for both button text change and state checking
        has_button_text = "submitBtn.textContent = 'Submitted';" in html_content
        has_state_check = "isSubmitted === 'true'" in html_content
        
        assert has_button_text and has_state_check, "Button state restoration logic not found"
    
    def test_sample_answer_display_preserved(self):
        """Test that sample answer display is preserved when show_answer is true."""
        with open(self.test_site_path, 'r', encoding='utf-8') as f:
            html_content = f.read()
        
        sample_answer_display = '<div class="answer-display"><strong>Sample Answer:</strong><br>'
        assert sample_answer_display in html_content, "Sample answer display not preserved"
    
    def test_submit_functions_exist(self):
        """Test that submit functions are generated for questions."""
        with open(self.test_site_path, 'r', encoding='utf-8') as f:
            html_content = f.read()
        
        submit_functions = re.findall(r'function submitAnswer_\w+\(\)', html_content)
        assert len(submit_functions) > 0, "No submit functions found"
    
    def test_submit_functions_have_proper_structure(self):
        """Test that submit functions have proper implementation."""
        with open(self.test_site_path, 'r', encoding='utf-8') as f:
            html_content = f.read()
        
        # Check for proper submit function structure
        required_elements = [
            "const textarea = document.getElementById",
            "const feedbackElement = document.getElementById", 
            "const submitBtn = document.querySelector",
            "answer.trim()"
        ]
        
        for element in required_elements:
            assert element in html_content, f"Submit function missing required element: {element}"


if __name__ == "__main__":
    # Manual test runner for debugging
    import sys
    import unittest
    
    class ManualTestRunner:
        def run_tests(self):
            print("🔍 Running Submit Button Improvements Tests...")
            
            # Find the test file
            base_path = Path(__file__).parent / ".."
            possible_paths = [
                base_path / "documentation" / "site" / "demo" / "index.html",
                base_path / "test-site" / "site" / "index.html"
            ]
            
            test_file = None
            for path in possible_paths:
                if path.exists():
                    test_file = str(path)
                    break
            
            if not test_file:
                print("❌ No test site found!")
                return False
            
            print(f"📁 Using test file: {test_file}")
            
            # Create test instance and run manually
            test_instance = TestSubmitButtonImprovements()
            test_instance.test_site_path = test_file
            
            tests = [
                ("Button text change", test_instance.test_submit_button_text_change),
                ("Button tooltip", test_instance.test_submit_button_tooltip),
                ("Success message removed", test_instance.test_success_message_removed),
                ("Button state restoration", test_instance.test_button_state_restoration),
                ("Sample answer display", test_instance.test_sample_answer_display_preserved),
                ("Submit functions exist", test_instance.test_submit_functions_exist),
                ("Submit function structure", test_instance.test_submit_functions_have_proper_structure)
            ]
            
            passed = 0
            failed = 0
            
            for test_name, test_func in tests:
                try:
                    test_func()
                    print(f"✅ {test_name} - PASSED")
                    passed += 1
                except Exception as e:
                    print(f"❌ {test_name} - FAILED: {e}")
                    failed += 1
            
            print(f"\n📊 Results: {passed} passed, {failed} failed")
            return failed == 0
    
    runner = ManualTestRunner()
    success = runner.run_tests()
    sys.exit(0 if success else 1)
