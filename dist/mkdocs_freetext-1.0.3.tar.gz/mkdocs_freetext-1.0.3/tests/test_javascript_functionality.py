"""
Test JavaScript functionality for submit button behavior.
Tests simulate DOM environment to verify JavaScript generation and execution.
"""

import pytest
import re
from mkdocs_freetext.plugin import FreetextPlugin


class TestJavaScriptFunctionality:
    """Test suite for JavaScript functionality and DOM behavior."""

    def setup_method(self):
        """Set up test fixtures."""
        self.plugin = FreetextPlugin()
        self.plugin.config = {
            'enable_auto_save': True,
            'show_character_count': True,
            'question_class': 'freetext-question',
            'assessment_class': 'freetext-assessment'
        }

    def test_javascript_function_generation(self):
        """Test that JavaScript functions are generated with correct names and IDs."""
        config = {
            'question': 'What is the capital of France?',
            'placeholder': 'Enter your answer...',
            'show_answer': True,
            'answer': 'Paris',
            'marks': 2,
            'type': 'short'
        }
        
        question_id = 'test123'
        js = self.plugin._generate_question_javascript(question_id, config)
        
        # Check that all required functions are generated
        assert f"function updateCharCount_{question_id}()" in js
        assert f"function autoSave_{question_id}()" in js
        assert f"function submitAnswer_{question_id}()" in js
        
        # Check function content
        assert f"getElementById('answer_{question_id}')" in js
        assert f"getElementById('feedback_{question_id}')" in js
        assert f"querySelector('[data-question-id=\"{question_id}\"] .submit-btn')" in js

    def test_dom_ready_code_separation(self):
        """Test that DOM ready code is properly separated from function definitions."""
        config = {
            'question': 'Test question',
            'placeholder': 'Test placeholder',
            'show_answer': True,
            'answer': 'Test answer',
            'marks': 1,
            'type': 'short'
        }
        
        question_id = 'test456'
        js = self.plugin._generate_question_javascript(question_id, config)
        
        # Should NOT contain DOMContentLoaded in the function-only output
        assert "DOMContentLoaded" not in js
        
        # But should have DOM ready code collected separately
        assert hasattr(self.plugin, 'current_page_dom_ready')

    def test_html_generation_with_consolidated_js(self):
        """Test that HTML generation properly consolidates JavaScript."""
        # Mock the page processing
        self.plugin.current_page_has_questions = False
        self.plugin.current_page_javascript = []
        self.plugin.current_page_dom_ready = []
        
        config = {
            'question': 'Test question with code block',
            'placeholder': 'Enter answer...',
            'show_answer': True,
            'answer': 'Sample answer',
            'marks': 5,
            'type': 'short'
        }
        
        question_id = 'code789'
        html = self.plugin._generate_question_html(config, question_id)
        
        # HTML should NOT contain inline script tags
        assert "<script>" not in html
        assert "</script>" not in html
        
        # But should contain the necessary HTML elements
        assert f'data-question-id="{question_id}"' in html
        assert f'id="answer_{question_id}"' in html
        assert f'onclick="submitAnswer_{question_id}()"' in html
        
        # JavaScript should be collected separately
        assert len(self.plugin.current_page_javascript) > 0

    def test_button_selector_uniqueness(self):
        """Test that button selectors are unique and won't conflict."""
        config = {
            'question': 'Question 1',
            'placeholder': 'Answer 1',
            'show_answer': True,
            'answer': 'Answer 1',
            'marks': 2,
            'type': 'short'
        }
        
        # Generate multiple questions
        question_ids = ['q1', 'q2', 'q3']
        selectors = []
        
        for qid in question_ids:
            js = self.plugin._generate_question_javascript(qid, config)
            # Extract button selector
            selector_match = re.search(r"querySelector\('([^']+)'\)", js)
            if selector_match:
                selectors.append(selector_match.group(1))
        
        # All selectors should be unique
        assert len(selectors) == len(set(selectors))
        
        # Each should contain the specific question ID
        for i, selector in enumerate(selectors):
            assert question_ids[i] in selector

    def test_character_count_function_integration(self):
        """Test character count function generation and integration."""
        config = {
            'question': 'Type something here',
            'placeholder': 'Type...',
            'show_answer': False,
            'answer': '',
            'marks': 1,
            'type': 'short'
        }
        
        question_id = 'char123'
        js = self.plugin._generate_question_javascript(question_id, config)
        
        # Character count function should be present
        assert f"function updateCharCount_{question_id}()" in js
        assert f"getElementById('charCount_{question_id}')" in js
        assert "textContent = textarea.value.length + ' characters'" in js

    def test_submit_button_behavior_code(self):
        """Test that submit button behavior changes are correctly generated."""
        config = {
            'question': 'Submit test question',
            'placeholder': 'Enter answer...',
            'show_answer': True,
            'answer': 'Test answer for validation',
            'marks': 3,
            'type': 'short'
        }
        
        question_id = 'submit789'
        js = self.plugin._generate_question_javascript(question_id, config)
        
        # Check for submit button improvements
        assert "submitBtn.textContent = 'Submitted';" in js
        assert "submitBtn.title = 'Click to resubmit';" in js
        
        # Should show sample answer when show_answer is True
        assert "Sample Answer" in js
        assert config['answer'] in js
        
        # Should NOT contain success message
        assert "Answer submitted successfully!" not in js

    def test_local_storage_integration(self):
        """Test localStorage save/restore functionality."""
        config = {
            'question': 'Storage test',
            'placeholder': 'Type here...',
            'show_answer': True,
            'answer': 'Stored answer',
            'marks': 2,
            'type': 'short'
        }
        
        question_id = 'storage456'
        js = self.plugin._generate_question_javascript(question_id, config)
        
        # Check localStorage setItem operations (in submit/autosave functions)
        assert f"localStorage.setItem('freetext_answer_{question_id}'" in js
        assert f"localStorage.setItem('freetext_submitted_{question_id}'" in js
        
        # Check localStorage getItem operations (in DOM ready code)
        dom_ready_code = '\n'.join(self.plugin.current_page_dom_ready)
        assert f"localStorage.getItem('freetext_answer_{question_id}')" in dom_ready_code
        assert f"localStorage.getItem('freetext_submitted_{question_id}')" in dom_ready_code

    def test_assessment_javascript_generation(self):
        """Test assessment JavaScript generation."""
        questions = [
            {
                'question': 'Assessment Question 1',
                'placeholder': 'Answer 1...',
                'show_answer': True,
                'answer': 'Answer 1',
                'marks': 3,
                'type': 'short'
            },
            {
                'question': 'Assessment Question 2',
                'placeholder': 'Answer 2...',
                'show_answer': False,
                'answer': 'Answer 2',
                'marks': 4,
                'type': 'long'
            }
        ]
        
        assessment_id = 'assess123'
        js = self.plugin._generate_assessment_javascript(assessment_id, questions)
        
        # Check assessment-specific functions
        assert f"function autoSaveAssessment_{assessment_id}()" in js
        assert f"function submitAssessment_{assessment_id}()" in js
        
        # Check individual question IDs
        assert f"{assessment_id}_q1" in js
        assert f"{assessment_id}_q2" in js
        
        # Check assessment button selector
        assert f"querySelector('[data-assessment-id=\"{assessment_id}\"] .submit-assessment-btn')" in js

    def test_consolidated_dom_ready_event(self):
        """Test that DOM ready events are properly consolidated."""
        # Simulate multiple questions on a page
        configs = [
            {'question': 'Q1', 'placeholder': 'A1', 'show_answer': True, 'answer': 'Ans1', 'marks': 1, 'type': 'short'},
            {'question': 'Q2', 'placeholder': 'A2', 'show_answer': True, 'answer': 'Ans2', 'marks': 2, 'type': 'short'},
            {'question': 'Q3', 'placeholder': 'A3', 'show_answer': False, 'answer': 'Ans3', 'marks': 3, 'type': 'long'}
        ]
        
        # Reset page state
        self.plugin.current_page_has_questions = False
        self.plugin.current_page_javascript = []
        self.plugin.current_page_dom_ready = []
        
        # Generate HTML for multiple questions
        for i, config in enumerate(configs):
            question_id = f"multi{i+1}"
            html = self.plugin._generate_question_html(config, question_id)
            self.plugin.current_page_has_questions = True
        
        # Should have multiple JavaScript function groups
        assert len(self.plugin.current_page_javascript) == 3
        
        # Should have DOM ready code for each question
        assert len(self.plugin.current_page_dom_ready) == 3

    def test_error_handling_in_javascript(self):
        """Test error handling in generated JavaScript."""
        config = {
            'question': 'Error test question',
            'placeholder': 'Enter something...',
            'show_answer': True,
            'answer': 'Error test answer',
            'marks': 1,
            'type': 'short'
        }
        
        question_id = 'error123'
        js = self.plugin._generate_question_javascript(question_id, config)
        
        # Should handle empty answers
        assert "if (answer.trim() === '')" in js
        assert "Please enter an answer before submitting" in js
        
        # Should check for element existence before manipulation
        assert "if (counter)" in js  # Character counter check
        
        # Textarea existence check is in DOM ready code
        dom_ready_code = '\n'.join(self.plugin.current_page_dom_ready)
        assert "if (textarea)" in dom_ready_code

    def test_html_escaping_in_javascript(self):
        """Test that HTML content is properly escaped in JavaScript strings."""
        config = {
            'question': 'Question with <script>alert("xss")</script> content',
            'placeholder': 'Type here...',
            'show_answer': True,
            'answer': 'Answer with "quotes" and <tags>',
            'marks': 2,
            'type': 'short'
        }
        
        question_id = 'escape123'
        js = self.plugin._generate_question_javascript(question_id, config)
        
        # Check that dangerous content is escaped or handled safely
        # The answer content should be present but escaped
        assert config['answer'] in js
        
        # Should not contain unescaped script tags in the final output
        assert "<script>" not in js or "alert" not in js

    def test_integration_with_page_processing(self):
        """Test integration with the full page processing pipeline."""
        # Mock a simple HTML page with freetext admonition
        html_input = '''
<h1>Test Page</h1>
<div class="admonition freetext">
<p class="admonition-title">Freetext</p>
<p>What is 2 + 2?</p>
<hr>
<p>marks: 1,
show_answer: true,
answer: 4</p>
</div>
'''
        
        # Mock page object
        class MockPage:
            def __init__(self):
                self.file = MockFile()
        
        class MockFile:
            def __init__(self):
                self.src_path = "test.md"
        
        page = MockPage()
        
        # Process the HTML through on_page_content (processes questions, stores JS data)
        content_result = self.plugin.on_page_content(html_input, page, {}, [])
        
        # Should contain a question but no JavaScript yet (that's added in on_post_page)
        assert 'data-question-id=' in content_result
        assert 'freetext-question' in content_result
        
        # Now simulate on_post_page to inject the JavaScript
        final_html = self.plugin.on_post_page(content_result, page, {})
        
        # Should have consolidated JavaScript at the end
        assert '<script>' in final_html
        assert 'function submitAnswer_' in final_html
        assert 'function updateCharCount_' in final_html
