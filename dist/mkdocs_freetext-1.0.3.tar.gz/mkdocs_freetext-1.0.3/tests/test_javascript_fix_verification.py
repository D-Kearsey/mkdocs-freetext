"""
Test to verify the JavaScript function definition fix.

This test specifically validates that the fix for initializing
current_page_dom_ready in on_page_content resolves the function
definition issues in the browser.
"""

import pytest
import re
from mkdocs_freetext.plugin import FreetextPlugin


def test_dom_ready_initialization_fix():
    """Test that current_page_dom_ready is properly initialized per page."""
    plugin = FreetextPlugin()
    plugin.load_config({})
    
    # Create mock pages
    mock_file1 = type('MockFile', (), {'src_path': 'page1.md'})()
    mock_page1 = type('MockPage', (), {'file': mock_file1})()
    
    mock_file2 = type('MockFile', (), {'src_path': 'page2.md'})()
    mock_page2 = type('MockPage', (), {'file': mock_file2})()
    
    # HTML content for first page
    html_page1 = '''
<div class="admonition freetext">
    <p class="admonition-title">Freetext</p>
    <p>Question on page 1?</p>
    <hr>
    <p>answer: Answer 1</p>
</div>
'''
    
    # HTML content for second page
    html_page2 = '''
<div class="admonition freetext">
    <p class="admonition-title">Freetext</p>
    <p>Question on page 2?</p>
    <hr>
    <p>type: long, answer: Answer 2</p>
</div>
'''
    
    # Process first page
    print("=== Processing Page 1 ===")
    processed_page1 = plugin.on_page_content(html_page1, mock_page1, {}, None)
    
    # Verify arrays are initialized
    assert hasattr(plugin, 'current_page_javascript'), "Should have current_page_javascript"
    assert hasattr(plugin, 'current_page_dom_ready'), "Should have current_page_dom_ready"
    
    page1_js_count = len(plugin.current_page_javascript)
    page1_dom_count = len(plugin.current_page_dom_ready)
    
    print(f"Page 1 - JavaScript functions: {page1_js_count}")
    print(f"Page 1 - DOM ready blocks: {page1_dom_count}")
    
    # Verify we have some JavaScript for page 1
    assert page1_js_count > 0, "Page 1 should have JavaScript functions"
    assert page1_dom_count > 0, "Page 1 should have DOM ready blocks"
    
    # Process second page
    print("\n=== Processing Page 2 ===")
    processed_page2 = plugin.on_page_content(html_page2, mock_page2, {}, None)
    
    page2_js_count = len(plugin.current_page_javascript)
    page2_dom_count = len(plugin.current_page_dom_ready)
    
    print(f"Page 2 - JavaScript functions: {page2_js_count}")
    print(f"Page 2 - DOM ready blocks: {page2_dom_count}")
    
    # Verify page 2 arrays were reset (not carrying over from page 1)
    assert page2_js_count > 0, "Page 2 should have JavaScript functions"
    assert page2_dom_count > 0, "Page 2 should have DOM ready blocks"
    
    # The key test: verify that the arrays were reset between pages
    # Each page should have its own content, not accumulated content
    page1_js_content = '\n'.join(plugin.page_javascript[mock_page1.file.src_path]['functions'])
    page2_js_content = '\n'.join(plugin.current_page_javascript)
    
    # Extract function names from each page
    page1_functions = re.findall(r'function\s+(\w+)\s*\(', page1_js_content)
    page2_functions = re.findall(r'function\s+(\w+)\s*\(', page2_js_content)
    
    print(f"Page 1 functions: {page1_functions}")
    print(f"Page 2 functions: {page2_functions}")
    
    # Functions should be different (different IDs)
    assert len(set(page1_functions) & set(page2_functions)) == 0, "Pages should have different function names"
    
    print("✅ DOM ready initialization fix verified - no function carryover between pages")


def test_complete_site_generation_workflow():
    """Test the complete workflow from multiple pages to final HTML injection."""
    plugin = FreetextPlugin()
    plugin.load_config({})
    
    # Simulate processing multiple pages like in real MkDocs build
    pages_data = [
        {
            'src_path': 'index.md',
            'html': '''
<div class="admonition freetext">
    <p class="admonition-title">Freetext</p>
    <p>What is Python?</p>
    <hr>
    <p>answer: Programming language</p>
</div>
'''
        },
        {
            'src_path': 'demo.md', 
            'html': '''
<div class="admonition freetext">
    <p class="admonition-title">Freetext</p>
    <p>Explain OOP?</p>
    <hr>
    <p>type: long, max_chars: 300, answer: Object-oriented programming</p>
</div>
'''
        }
    ]
    
    processed_pages = []
    
    # Process each page (simulating MkDocs on_page_content calls)
    for page_data in pages_data:
        mock_file = type('MockFile', (), {'src_path': page_data['src_path']})()
        mock_page = type('MockPage', (), {'file': mock_file})()
        
        print(f"\n=== Processing {page_data['src_path']} ===")
        
        # Process content
        processed_html = plugin.on_page_content(page_data['html'], mock_page, {}, None)
        
        # Create full HTML page
        full_html = f'''<!DOCTYPE html>
<html>
<head><title>{page_data['src_path']}</title></head>
<body>{processed_html}</body>
</html>'''
        
        # Inject JavaScript (simulating MkDocs on_post_page call)
        final_html = plugin.on_post_page(full_html, mock_page, {})
        
        processed_pages.append({
            'src_path': page_data['src_path'],
            'processed_html': processed_html,
            'final_html': final_html
        })
        
        print(f"JavaScript functions collected: {len(plugin.current_page_javascript)}")
        print(f"DOM ready blocks collected: {len(plugin.current_page_dom_ready)}")
    
    # Verify each page has proper JavaScript injection
    for page in processed_pages:
        print(f"\n=== Verifying {page['src_path']} ===")
        
        # Extract function calls from HTML elements
        onclick_calls = re.findall(r'onclick="([^"]+)"', page['final_html'])
        oninput_calls = re.findall(r'oninput="([^"]+)"', page['final_html'])
        
        print(f"onclick calls: {onclick_calls}")
        print(f"oninput calls: {oninput_calls}")
        
        # Extract function definitions from JavaScript
        function_defs = re.findall(r'function\s+(\w+)\s*\(', page['final_html'])
        print(f"Function definitions: {function_defs}")
        
        # Verify each onclick/oninput call has a corresponding function definition
        for onclick in onclick_calls:
            # Extract function name (remove parentheses and parameters)
            func_name = onclick.split('(')[0]
            assert func_name in function_defs, f"Missing function definition for onclick: {func_name}"
            print(f"✅ Found function definition for onclick: {func_name}")
        
        for oninput in oninput_calls:
            # Handle multiple function calls in oninput
            for func_call in oninput.split(';'):
                func_call = func_call.strip()
                if func_call:
                    func_name = func_call.split('(')[0]
                    assert func_name in function_defs, f"Missing function definition for oninput: {func_name}"
                    print(f"✅ Found function definition for oninput: {func_name}")
        
        # Verify script tags exist
        assert '<script>' in page['final_html'], f"Page {page['src_path']} should have script tags"
        assert 'DOMContentLoaded' in page['final_html'], f"Page {page['src_path']} should have DOM ready events"
        
        print(f"✅ Page {page['src_path']} JavaScript injection verified")
    
    print("\n✅ Complete site generation workflow verified - all pages have proper JavaScript injection")


def test_triple_quotes_with_javascript_generation():
    """Test that triple quotes work correctly with JavaScript generation."""
    plugin = FreetextPlugin()
    plugin.load_config({})
    
    # Create mock page
    mock_file = type('MockFile', (), {'src_path': 'triple_quotes_test.md'})()
    mock_page = type('MockPage', (), {'file': mock_file})()
    
    # HTML with triple quotes in answer
    html_with_triple_quotes = '''
<div class="admonition freetext">
    <p class="admonition-title">Freetext</p>
    <p>What is the capital of France?</p>
    <hr>
    <p>placeholder: Enter your answer here..., marks: 2, show_answer: true, answer: """Paris is the capital of France, and it is also known as the City of Light, home to the Eiffel Tower."""</p>
</div>
'''
    
    # Process content
    processed_content = plugin.on_page_content(html_with_triple_quotes, mock_page, {}, None)
    
    # Verify content was processed
    assert 'freetext-question' in processed_content, "Should contain question class"
    assert '(2 marks)' in processed_content, "Should show marks"
    
    # Create full HTML and inject JavaScript
    full_html = f'<!DOCTYPE html><html><body>{processed_content}</body></html>'
    final_html = plugin.on_post_page(full_html, mock_page, {})
    
    # Verify JavaScript was injected correctly
    assert '<script>' in final_html, "Should contain script tags"
    assert 'function submitAnswer_' in final_html, "Should contain submit function"
    assert 'DOMContentLoaded' in final_html, "Should contain DOM ready event"
    
    # Extract and verify function names match HTML attributes
    onclick_matches = re.findall(r'onclick="(submitAnswer_[^"]+)"', final_html)
    function_matches = re.findall(r'function (submitAnswer_[^(]+)\(', final_html)
    
    assert len(onclick_matches) > 0, "Should find onclick attributes"
    assert len(function_matches) > 0, "Should find function definitions"
    
    # Verify onclick calls have matching function definitions
    for onclick_func in onclick_matches:
        func_name = onclick_func.replace('()', '')
        assert func_name in function_matches, f"Missing function definition for {func_name}"
    
    print("✅ Triple quotes work correctly with JavaScript generation")


if __name__ == "__main__":
    print("🧪 Running JavaScript Function Definition Fix Tests...")
    print()
    
    try:
        test_dom_ready_initialization_fix()
        print()
        test_complete_site_generation_workflow()
        print()
        test_triple_quotes_with_javascript_generation()
        
        print()
        print("🎉 All JavaScript function definition fix tests passed!")
        print("The DOM ready initialization fix resolves the function definition issues.")
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
