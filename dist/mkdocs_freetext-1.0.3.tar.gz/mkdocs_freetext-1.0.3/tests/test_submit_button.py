"""
Test submit button improvements.
Tests that submit button behavior is correctly implemented in JavaScript generation.
"""

import pytest
import re
from mkdocs_freetext.plugin import FreetextPlugin


class TestSubmitButtonImprovements:
    """Test suite for submit button improvements."""

    def setup_method(self):
        """Set up test fixtures."""
        self.plugin = FreetextPlugin()
        self.plugin.config = {
            'enable_auto_save': True,
            'show_character_count': True,
            'question_class': 'freetext-question',
            'assessment_class': 'freetext-assessment'
        }

    def test_individual_question_submit_button_text_change(self):
        """Test that individual question submit function changes button text to 'Submitted'."""
        config = {
            'question': 'What is the capital of France?',
            'placeholder': 'Enter your answer...',
            'show_answer': True,
            'answer': 'Paris',
            'marks': 2,
            'type': 'short'
        }
        
        js = self.plugin._generate_question_javascript('test123', config)
        
        # Should contain button text change
        assert "submitBtn.textContent = 'Submitted';" in js
        
    def test_individual_question_submit_button_tooltip(self):
        """Test that individual question submit function adds tooltip."""
        config = {
            'question': 'What is the capital of France?',
            'placeholder': 'Enter your answer...',
            'show_answer': True,
            'answer': 'Paris',
            'marks': 2,
            'type': 'short'
        }
        
        js = self.plugin._generate_question_javascript('test123', config)
        
        # Should contain tooltip addition
        assert "submitBtn.title = 'Click to resubmit';" in js
        
    def test_individual_question_no_success_message(self):
        """Test that individual question submit function removes success message."""
        config = {
            'question': 'What is the capital of France?',
            'placeholder': 'Enter your answer...',
            'show_answer': True,
            'answer': 'Paris',
            'marks': 2,
            'type': 'short'
        }
        
        js = self.plugin._generate_question_javascript('test123', config)
        
        # Should NOT contain success message
        assert "Answer submitted successfully!" not in js
        
    def test_individual_question_sample_answer_preserved(self):
        """Test that individual question submit function preserves sample answer display."""
        config = {
            'question': 'What is the capital of France?',
            'placeholder': 'Enter your answer...',
            'show_answer': True,
            'answer': 'Paris',
            'marks': 2,
            'type': 'short'
        }
        
        js = self.plugin._generate_question_javascript('test123', config)
        
        # Should contain sample answer display when show_answer is true
        assert '<div class="answer-display"><strong>Sample Answer:</strong><br>' in js
        
    def test_individual_question_no_sample_answer_when_disabled(self):
        """Test that individual question submit function hides feedback when show_answer is false."""
        config = {
            'question': 'What is the capital of France?',
            'placeholder': 'Enter your answer...',
            'show_answer': False,
            'answer': 'Paris',
            'marks': 2,
            'type': 'short'
        }
        
        js = self.plugin._generate_question_javascript('test123', config)
        
        # Should hide feedback when show_answer is false
        assert "feedback.style.display = 'none';" in js
        
    def test_individual_question_button_state_restoration(self):
        """Test that individual question auto-load function restores button state."""
        config = {
            'question': 'What is the capital of France?',
            'placeholder': 'Enter your answer...',
            'show_answer': True,
            'answer': 'Paris',
            'marks': 2,
            'type': 'short'
        }
        
        js = self.plugin._generate_question_javascript('test123', config)
        
        # Should restore button state
        assert "isSubmitted === 'true'" in js
        assert "submitBtn.textContent = 'Submitted';" in js
        assert "submitBtn.title = 'Click to resubmit';" in js
        
    def test_assessment_submit_button_text_change(self):
        """Test that assessment submit function changes button text to 'Submitted'."""
        questions = [
            {
                'question': 'Question 1?',
                'placeholder': 'Answer 1...',
                'show_answer': True,
                'answer': 'Answer 1',
                'marks': 2,
                'type': 'short'
            },
            {
                'question': 'Question 2?',
                'placeholder': 'Answer 2...',
                'show_answer': True,
                'answer': 'Answer 2',
                'marks': 3,
                'type': 'short'
            }
        ]
        
        js = self.plugin._generate_assessment_javascript('test456', questions)
        
        # Should contain button text change
        assert "submitBtn.textContent = 'Submitted';" in js
        
    def test_assessment_submit_button_tooltip(self):
        """Test that assessment submit function adds tooltip."""
        questions = [
            {
                'question': 'Question 1?',
                'placeholder': 'Answer 1...',
                'show_answer': True,
                'answer': 'Answer 1',
                'marks': 2,
                'type': 'short'
            }
        ]
        
        js = self.plugin._generate_assessment_javascript('test456', questions)
        
        # Should contain tooltip addition
        assert "submitBtn.title = 'Click to resubmit';" in js
        
    def test_assessment_no_success_message(self):
        """Test that assessment submit function removes success message."""
        questions = [
            {
                'question': 'Question 1?',
                'placeholder': 'Answer 1...',
                'show_answer': True,
                'answer': 'Answer 1',
                'marks': 2,
                'type': 'short'
            }
        ]
        
        js = self.plugin._generate_assessment_javascript('test456', questions)
        
        # Should hide assessment feedback instead of showing success message
        assert "assessmentFeedback.style.display = 'none';" in js
        # Should NOT contain success message
        assert "Assessment submitted successfully!" not in js
        
    def test_assessment_individual_sample_answers_preserved(self):
        """Test that assessment submit function preserves individual question sample answers."""
        questions = [
            {
                'question': 'Question 1?',
                'placeholder': 'Answer 1...',
                'show_answer': True,
                'answer': 'Answer 1',
                'marks': 2,
                'type': 'short'
            },
            {
                'question': 'Question 2?',
                'placeholder': 'Answer 2...',
                'show_answer': False,
                'answer': 'Answer 2',
                'marks': 3,
                'type': 'short'
            }
        ]
        
        js = self.plugin._generate_assessment_javascript('test456', questions)
        
        # Should show sample answer for question with show_answer=True
        assert 'feedback_test456_q1.innerHTML = \'<div class="answer-display"><strong>Sample Answer:</strong><br>Answer 1</div>\';' in js
        # Should have proper conditional check for question with show_answer=False
        # The JavaScript should contain the feedback assignment but wrapped in an if (false) condition
        assert 'if (true)' in js  # For question 1 with show_answer=True
        assert 'if (false)' in js  # For question 2 with show_answer=False
        
    def test_question_id_consistency(self):
        """Test that question IDs are used consistently across JavaScript functions."""
        config = {
            'question': 'Test question?',
            'placeholder': 'Test placeholder...',
            'show_answer': True,
            'answer': 'Test answer',
            'marks': 1,
            'type': 'short'
        }
        
        question_id = 'abc123'
        js = self.plugin._generate_question_javascript(question_id, config)
        
        # Count occurrences of the question ID in various contexts
        id_patterns = [
            f'answer_{question_id}',
            f'feedback_{question_id}',
            f'submitAnswer_{question_id}',
            f'updateCharCount_{question_id}',
            f'autoSave_{question_id}'
        ]
        
        for pattern in id_patterns:
            assert pattern in js, f"Pattern '{pattern}' should be present in generated JavaScript"
            
    def test_assessment_id_consistency(self):
        """Test that assessment IDs are used consistently across JavaScript functions."""
        questions = [
            {
                'question': 'Question 1?',
                'placeholder': 'Answer 1...',
                'show_answer': True,
                'answer': 'Answer 1',
                'marks': 2,
                'type': 'short'
            }
        ]
        
        assessment_id = 'xyz789'
        js = self.plugin._generate_assessment_javascript(assessment_id, questions)
        
        # Count occurrences of the assessment ID in various contexts
        id_patterns = [
            f'assessment_feedback_{assessment_id}',
            f'submitAssessment_{assessment_id}',
            f'autoSaveAssessment_{assessment_id}',
            f'freetext_assessment_{assessment_id}',
            f'{assessment_id}_q1'  # Question ID format
        ]
        
        for pattern in id_patterns:
            assert pattern in js, f"Pattern '{pattern}' should be present in generated JavaScript"
            
    def test_button_selector_specificity(self):
        """Test that button selectors are specific enough to avoid conflicts."""
        config = {
            'question': 'Test question?',
            'placeholder': 'Test placeholder...',
            'show_answer': True,
            'answer': 'Test answer',
            'marks': 1,
            'type': 'short'
        }
        
        question_id = 'test123'
        js = self.plugin._generate_question_javascript(question_id, config)
        
        # Should use specific selector for individual questions
        assert f'[data-question-id="{question_id}"] .submit-btn' in js
        
        # Test assessment button selector
        questions = [config]
        assessment_id = 'assess456'
        assessment_js = self.plugin._generate_assessment_javascript(assessment_id, questions)
        
        # Should use specific selector for assessments
        assert f'[data-assessment-id="{assessment_id}"] .submit-assessment-btn' in assessment_js
