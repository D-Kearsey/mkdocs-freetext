"""
Test the enhanced triple quote functionality of the MkDocs Free-Text Plugin.

This test validates that the _parse_comma_separated_config method properly
handles triple quotes for complex answers containing commas and quotes.
"""

import sys
import os

# Add the mkdocs_freetext module to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from mkdocs_freetext.plugin import FreetextPlugin


def test_basic_comma_separated_config():
    """Test basic comma-separated configuration parsing."""
    plugin = FreetextPlugin()
    
    config_string = "question: What is Python?, marks: 5, rows: 3"
    result = plugin._parse_comma_separated_config(config_string)
    
    expected = {
        "question": "What is Python?",
        "marks": "5", 
        "rows": "3"
    }
    
    assert result == expected
    print("✅ Basic comma-separated config parsing works")


def test_triple_quote_with_commas():
    """Test triple quote parsing with commas inside values."""
    plugin = FreetextPlugin()
    
    config_string = 'question: """List languages: Python, JavaScript, SQL""", marks: 8'
    result = plugin._parse_comma_separated_config(config_string)
    
    expected = {
        "question": "List languages: Python, JavaScript, SQL",
        "marks": "8"
    }
    
    assert result == expected
    print("✅ Triple quote with commas works")


def test_triple_quote_with_nested_quotes():
    """Test triple quotes containing regular quotes."""
    plugin = FreetextPlugin()
    
    config_string = 'question: """He said "Hello" and it\'s working!""", marks: 3'
    result = plugin._parse_comma_separated_config(config_string)
    
    expected = {
        "question": 'He said "Hello" and it\'s working!',
        "marks": "3"
    }
    
    assert result == expected
    print("✅ Triple quote with nested quotes works")


def test_multiple_triple_quote_sections():
    """Test multiple triple quote sections in same config."""
    plugin = FreetextPlugin()
    
    config_string = 'question: """Complex, question""", sample_answers: """Answer 1, with commas""", marks: 5'
    result = plugin._parse_comma_separated_config(config_string)
    
    expected = {
        "question": "Complex, question",
        "sample_answers": "Answer 1, with commas", 
        "marks": "5"
    }
    
    assert result == expected
    print("✅ Multiple triple quote sections work")


def test_mixed_quotes_and_regular():
    """Test mixing triple quotes with regular values."""
    plugin = FreetextPlugin()
    
    config_string = 'question: Simple question, sample_answers: """Complex, answer""", marks: 4, rows: 6'
    result = plugin._parse_comma_separated_config(config_string)
    
    expected = {
        "question": "Simple question",
        "sample_answers": "Complex, answer",
        "marks": "4",
        "rows": "6"
    }
    
    assert result == expected
    print("✅ Mixed quotes and regular values work")


def test_empty_triple_quotes():
    """Test empty triple quote sections."""
    plugin = FreetextPlugin()
    
    config_string = 'question: """Empty answer: """, marks: 2'
    result = plugin._parse_comma_separated_config(config_string)
    
    expected = {
        "question": "Empty answer: ",
        "marks": "2"
    }
    
    assert result == expected
    print("✅ Empty triple quotes work")


def test_whitespace_handling():
    """Test whitespace handling in triple quotes."""
    plugin = FreetextPlugin()
    
    config_string = 'question: """  Answer with spaces  """, marks: 3'
    result = plugin._parse_comma_separated_config(config_string)
    
    expected = {
        "question": "  Answer with spaces  ",
        "marks": "3"
    }
    
    assert result == expected
    print("✅ Whitespace handling in triple quotes works")


def test_complex_real_world_example():
    """Test a complex real-world configuration example."""
    plugin = FreetextPlugin()
    
    config_string = '''question: """Explain the differences between Python, JavaScript, and SQL. Include their primary use cases.""", 
                      sample_answers: """Python: General-purpose programming, data science, automation. JavaScript: Web development, both frontend and backend. SQL: Database queries and management.""",
                      marks: 10, 
                      rows: 6,
                      placeholder: """Discuss each language's strengths..."""'''
    
    result = plugin._parse_comma_separated_config(config_string)
    
    expected = {
        "question": "Explain the differences between Python, JavaScript, and SQL. Include their primary use cases.",
        "sample_answers": "Python: General-purpose programming, data science, automation. JavaScript: Web development, both frontend and backend. SQL: Database queries and management.",
        "marks": "10",
        "rows": "6", 
        "placeholder": "Discuss each language's strengths..."
    }
    
    assert result == expected
    print("✅ Complex real-world example works")


def test_backward_compatibility():
    """Test that old-style configurations still work."""
    plugin = FreetextPlugin()
    
    # Old style without triple quotes
    old_config = "question: What is Python?, marks: 5, rows: 3"
    result = plugin._parse_comma_separated_config(old_config)
    
    expected = {
        "question": "What is Python?",
        "marks": "5",
        "rows": "3"
    }
    
    assert result == expected
    print("✅ Backward compatibility maintained")


def run_all_tests():
    """Run all triple quote tests."""
    print("🚀 Running Triple Quote Functionality Tests")
    print("=" * 50)
    
    test_functions = [
        test_basic_comma_separated_config,
        test_triple_quote_with_commas,
        test_triple_quote_with_nested_quotes,
        test_multiple_triple_quote_sections,
        test_mixed_quotes_and_regular,
        test_empty_triple_quotes,
        test_whitespace_handling,
        test_complex_real_world_example,
        test_backward_compatibility
    ]
    
    passed = 0
    failed = 0
    
    for test_func in test_functions:
        try:
            test_func()
            passed += 1
        except Exception as e:
            print(f"❌ {test_func.__name__} failed: {e}")
            failed += 1
    
    print("\n" + "=" * 50)
    print(f"📊 Test Results: {passed} passed, {failed} failed")
    
    if failed == 0:
        print("🎉 All triple quote tests passed!")
        return True
    else:
        print(f"💥 {failed} tests failed")
        return False


if __name__ == "__main__":
    success = run_all_tests()
    exit_code = 0 if success else 1
    print(f"\nExiting with code: {exit_code}")
    exit(exit_code)
