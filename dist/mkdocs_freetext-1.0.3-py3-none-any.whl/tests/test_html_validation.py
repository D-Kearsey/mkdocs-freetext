"""
Test suite for validating the JavaScript auto-fix functionality against actual HTML content.

This module tests the actual HTML structure and JavaScript that was generated,
comparing it with the backup to ensure all improvements are properly implemented.
"""

import pytest
import re
from bs4 import BeautifulSoup
import os


class TestHTMLStructureValidation:
    """Test the actual HTML structure and JavaScript implementation."""
    
    def setup_method(self):
        """Set up paths to current and backup HTML files."""
        base_path = os.path.join(os.path.dirname(__file__), "..", "documentation", "site", "demo")
        self.current_html_path = os.path.join(base_path, "index.html")
        self.backup_html_path = os.path.join(base_path, "index.html.backup")
        
        # Load both files
        with open(self.current_html_path, 'r', encoding='utf-8') as f:
            self.current_html = f.read()
        
        with open(self.backup_html_path, 'r', encoding='utf-8') as f:
            self.backup_html = f.read()
    
    def test_auto_fix_function_exists(self):
        """Test that the initAutoFix function exists in current HTML."""
        assert "function initAutoFix()" in self.current_html
        assert "function initAutoFix()" not in self.backup_html
    
    def test_character_count_functions_exist(self):
        """Test that character count functions are properly defined."""
        # Look for updateCharCount functions with question IDs
        pattern = r"function updateCharCount_([a-f0-9]+)\(\)"
        matches = re.findall(pattern, self.current_html)
        
        # Should have multiple character count functions for different questions
        assert len(matches) > 0, "No updateCharCount functions found"
        
        # Test that each function has proper structure
        for question_id in matches:
            func_pattern = rf"function updateCharCount_{question_id}\(\).*?textarea\.value\.length"
            assert re.search(func_pattern, self.current_html, re.DOTALL), f"updateCharCount_{question_id} missing proper implementation"
    
    def test_submit_answer_functions_exist(self):
        """Test that submit answer functions are properly defined."""
        pattern = r"function submitAnswer_([a-f0-9]+)\(\)"
        matches = re.findall(pattern, self.current_html)
        
        assert len(matches) > 0, "No submitAnswer functions found"
        
        # Test that each function has proper structure
        for question_id in matches:
            func_pattern = rf"function submitAnswer_{question_id}\(\).*?feedbackElement"
            assert re.search(func_pattern, self.current_html, re.DOTALL), f"submitAnswer_{question_id} missing proper implementation"
    
    def test_event_listener_improvements(self):
        """Test that event listeners are properly implemented."""
        # Should have DOM ready event listener
        assert "document.addEventListener('DOMContentLoaded', initAutoFix)" in self.current_html
        
        # Should have immediate execution as well
        assert "initAutoFix();" in self.current_html
        
        # Should remove old event listeners before adding new ones
        assert "removeEventListener('input'" in self.current_html
    
    def test_console_logging_implementation(self):
        """Test that comprehensive console logging is implemented."""
        logging_patterns = [
            r"console\.log\('✅",
            r"console\.log\('ℹ️",
            r"console\.warn\('❌",
            r"console\.log\(`.*?Functions found for.*?\`"
        ]
        
        for pattern in logging_patterns:
            assert re.search(pattern, self.current_html), f"Logging pattern {pattern} not found"
    
    def test_auto_save_handling_improvement(self):
        """Test that autoSave function handling was improved."""
        # Should have informational message instead of warning
        assert "ℹ️ autoSave function not implemented" in self.current_html
        
        # Should not have the old warning message
        assert "❌ autoSave function not found for" not in self.current_html
        
        # Should check for autoSave function existence before removing listener
        assert "if (autoSaveFunc)" in self.current_html
    
    def test_dom_verification_mechanism(self):
        """Test that DOM verification mechanism is implemented."""
        # Should have setTimeout verification
        assert "setTimeout(function()" in self.current_html
        
        # Should verify textContent persistence
        verification_pattern = r"setTimeout\(function\(\).*?textContent.*?\}, 10\)"
        assert re.search(verification_pattern, self.current_html, re.DOTALL), "DOM verification mechanism not found"
    
    def test_unique_question_ids(self):
        """Test that all questions have unique IDs."""
        soup = BeautifulSoup(self.current_html, 'html.parser')
        question_divs = soup.find_all('div', {'data-question-id': True})
        
        question_ids = [div['data-question-id'] for div in question_divs]
        
        # Should have questions
        assert len(question_ids) > 0, "No questions found"
        
        # All IDs should be unique
        assert len(question_ids) == len(set(question_ids)), "Duplicate question IDs found"
    
    def test_html_structure_integrity(self):
        """Test that HTML structure is intact and valid."""
        soup = BeautifulSoup(self.current_html, 'html.parser')
        
        # Should be valid HTML
        assert soup.html is not None
        assert soup.head is not None
        assert soup.body is not None
        
        # Should have questions with required elements
        question_divs = soup.find_all('div', {'data-question-id': True})
        
        for question_div in question_divs:
            question_id = question_div['data-question-id']
            
            # Each question should have required elements
            textarea = soup.find('textarea', id=f'answer_{question_id}')
            char_count = soup.find('div', id=f'charCount_{question_id}')
            
            if textarea:  # Some questions might not have textareas (display only)
                assert char_count is not None, f"Question {question_id} missing character count element"


class TestJavaScriptSyntaxValidation:
    """Test JavaScript syntax and structure validation."""
    
    def setup_method(self):
        """Load the current HTML content."""
        base_path = os.path.join(os.path.dirname(__file__), "..", "documentation", "site", "demo")
        self.current_html_path = os.path.join(base_path, "index.html")
        
        with open(self.current_html_path, 'r', encoding='utf-8') as f:
            self.current_html = f.read()
    
    def test_javascript_syntax_errors_fixed(self):
        """Test that JavaScript syntax errors have been fixed."""
        # Should not have the old problematic syntax
        assert "Identifier 'savedAnswer' has already been declared" not in self.current_html
        
        # Should not have unescaped apostrophes in strings
        problem_patterns = [
            r"'It's'",  # Should be escaped as "It\'s" or use double quotes
            r"'don't'",  # Should be escaped
            r"'can't'"   # Should be escaped
        ]
        
        for pattern in problem_patterns:
            matches = re.findall(pattern, self.current_html)
            # If found, they should be properly escaped or in double quotes
            for match in matches:
                # Check if it's properly escaped or in a comment
                context_pattern = rf"(//.*?{re.escape(match)}|/\*.*?{re.escape(match)}.*?\*/|\"{re.escape(match)}\")"
                context_matches = re.findall(context_pattern, self.current_html, re.DOTALL)
                assert len(context_matches) > 0 or match not in self.current_html, f"Unescaped apostrophe found: {match}"
    
    def test_function_declarations_unique(self):
        """Test that all function declarations are unique."""
        # Extract all function declarations
        function_pattern = r"function\s+(\w+)\s*\("
        functions = re.findall(function_pattern, self.current_html)
        
        # Check for duplicates
        function_counts = {}
        for func in functions:
            function_counts[func] = function_counts.get(func, 0) + 1
        
        duplicates = {func: count for func, count in function_counts.items() if count > 1}
        assert len(duplicates) == 0, f"Duplicate function declarations found: {duplicates}"
    
    def test_variable_declarations_scoped(self):
        """Test that variable declarations are properly scoped."""
        # Look for potentially problematic variable declarations
        problematic_vars = ['savedAnswer', 'isSubmitted']
        
        for var_name in problematic_vars:
            # Should not have multiple declarations in global scope
            global_declarations = re.findall(rf"(?:var|let|const)\s+{var_name}", self.current_html)
            
            # If multiple declarations exist, they should be in different scopes
            if len(global_declarations) > 1:
                # Check if they're in different function scopes
                function_scoped_pattern = rf"function\s+\w+.*?(?:var|let|const)\s+{var_name}"
                scoped_declarations = re.findall(function_scoped_pattern, self.current_html, re.DOTALL)
                
                assert len(scoped_declarations) >= len(global_declarations) - 1, f"Variable {var_name} declared multiple times in global scope"


class TestBackupComparison:
    """Compare current implementation with backup to ensure all improvements are captured."""
    
    def setup_method(self):
        """Load both files for comparison."""
        base_path = os.path.join(os.path.dirname(__file__), "..", "documentation", "site", "demo")
        self.current_html_path = os.path.join(base_path, "index.html")
        self.backup_html_path = os.path.join(base_path, "index.html.backup")
        
        with open(self.current_html_path, 'r', encoding='utf-8') as f:
            self.current_html = f.read()
        
        with open(self.backup_html_path, 'r', encoding='utf-8') as f:
            self.backup_html = f.read()
    
    def test_new_features_added(self):
        """Test that new features are present in current but not in backup."""
        new_features = [
            "function initAutoFix()",
            "removeEventListener('input'",
            "console.log('✅",
            "setTimeout(function()",
            "ℹ️ autoSave function not implemented"
        ]
        
        for feature in new_features:
            assert feature in self.current_html, f"New feature '{feature}' not found in current HTML"
            assert feature not in self.backup_html, f"Feature '{feature}' should not be in backup"
    
    def test_problematic_code_removed(self):
        """Test that problematic code from backup has been fixed."""
        problematic_patterns = [
            "❌ autoSave function not found for",
            "textarea.removeEventListener('input', autoSaveFunc);",  # Without null check
        ]
        
        for pattern in problematic_patterns:
            if pattern in self.backup_html:
                assert pattern not in self.current_html, f"Problematic pattern '{pattern}' still exists in current HTML"
    
    def test_structure_preserved(self):
        """Test that the overall HTML structure is preserved."""
        current_soup = BeautifulSoup(self.current_html, 'html.parser')
        backup_soup = BeautifulSoup(self.backup_html, 'html.parser')
        
        # Should have same number of questions
        current_questions = current_soup.find_all('div', {'data-question-id': True})
        backup_questions = backup_soup.find_all('div', {'data-question-id': True})
        
        assert len(current_questions) == len(backup_questions), "Number of questions changed"
        
        # Question IDs should be the same
        current_ids = {q['data-question-id'] for q in current_questions}
        backup_ids = {q['data-question-id'] for q in backup_questions}
        
        assert current_ids == backup_ids, "Question IDs changed"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
