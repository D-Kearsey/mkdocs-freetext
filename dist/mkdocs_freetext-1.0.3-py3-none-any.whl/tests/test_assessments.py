"""
Test assessment and multi-question functionality of the MkDocs Free-Text Plugin.

This test suite verifies:
1. Assessment block processing with multiple questions
2. Question shuffling functionality 
3. Assessment-level configuration (title, shuffle settings)
4. Total marks calculation and display
"""

import pytest
from mkdocs_freetext.plugin import FreetextPlugin
import random


def test_assessment_block_processing():
    """Test that !!! freetext-assessment syntax processes multiple questions correctly."""
    plugin = FreetextPlugin()
    plugin.load_config({})
    
    # Create mock page
    mock_file = type('MockFile', (), {'src_path': 'test.md'})()
    mock_page = type('MockPage', (), {'file': mock_file})()
    
    # HTML with assessment containing multiple questions
    html_assessment = '''
<div class="admonition freetext-assessment">
    <p class="admonition-title">Freetext Assessment</p>
    <p>title: Python Fundamentals Quiz</p>
    <p>question: What is a variable in Python?</p>
    <hr>
    <p>marks: 3,
    placeholder: Explain what a variable is...</p>
    <hr>
    <p>question: Explain the difference between lists and tuples.</p>
    <hr>
    <p>marks: 5,
    type: long,
    placeholder: Compare and contrast lists and tuples...</p>
</div>
'''
    
    # Process the HTML
    result = plugin.on_page_content(html_assessment, mock_page, {}, None)
    
    # Verify assessment structure
    assert 'freetext-assessment' in result, "Should contain assessment class"
    assert 'Python Fundamentals Quiz' in result, "Should show assessment title"
    assert 'Total: 8 marks' in result, "Should show total marks (3+5)"
    
    # Verify individual questions
    assert 'What is a variable in Python?' in result, "Should contain first question"
    assert 'Explain the difference between lists and tuples.' in result, "Should contain second question"
    assert result.count('assessment-question') == 2, "Should have 2 assessment questions"
    assert result.count('<textarea') == 2, "Should have 2 textareas"
    
    # Verify question numbering
    assert '1.' in result, "Should number first question"
    assert '2.' in result, "Should number second question"
    
    # Verify submit button
    assert 'Submit Assessment' in result, "Should have assessment submit button"


def test_assessment_shuffling():
    """Test question shuffling when shuffle: true is set in assessment config."""
    plugin = FreetextPlugin()
    plugin.load_config({})
    
    # Create mock page
    mock_file = type('MockFile', (), {'src_path': 'test.md'})()
    mock_page = type('MockPage', (), {'file': mock_file})()
    
    # HTML with assessment that has shuffling enabled
    html_shuffled = '''
<div class="admonition freetext-assessment">
    <p class="admonition-title">Freetext Assessment</p>
    <p>title: Shuffled Quiz,
    shuffle: true</p>
    <p>question: Question A</p>
    <hr>
    <p>marks: 2</p>
    <hr>
    <p>question: Question B</p>
    <hr>
    <p>marks: 3</p>
    <hr>
    <p>question: Question C</p>
    <hr>
    <p>marks: 4</p>
</div>
'''
    
    # Process the HTML
    result = plugin.on_page_content(html_shuffled, mock_page, {}, None)
    
    # Verify shuffle functionality is included
    assert 'data-shuffle="true"' in result, "Should have shuffle attribute set to true"
    assert 'shuffleQuestions_' in result, "Should include shuffle JavaScript function"
    assert 'Fisher-Yates shuffle' in result, "Should include shuffle algorithm in JS"
    
    # Verify all questions are still present
    assert 'Question A' in result, "Should contain Question A"
    assert 'Question B' in result, "Should contain Question B" 
    assert 'Question C' in result, "Should contain Question C"
    assert 'Total: 9 marks' in result, "Should show correct total marks"


def test_assessment_title_and_config():
    """Test assessment-level configuration parsing and display."""
    plugin = FreetextPlugin()
    plugin.load_config({})
    
    # Create mock page
    mock_file = type('MockFile', (), {'src_path': 'test.md'})()
    mock_page = type('MockPage', (), {'file': mock_file})()
    
    # HTML with custom assessment configuration
    html_custom_config = '''
<div class="admonition freetext-assessment">
    <p class="admonition-title">Freetext Assessment</p>
    <p>title: Advanced Python Assessment,
    shuffle: false</p>
    <p>question: Describe object-oriented programming.</p>
    <hr>
    <p>marks: 10,
    type: long</p>
</div>
'''
    
    # Process the HTML
    result = plugin.on_page_content(html_custom_config, mock_page, {}, None)
    
    # Verify custom title
    assert 'Advanced Python Assessment' in result, "Should show custom assessment title"
    assert '<h3>Advanced Python Assessment</h3>' in result, "Should use h3 for title"
    
    # Verify shuffle is disabled
    assert 'data-shuffle="false"' in result, "Should have shuffle disabled"
    
    # Verify assessment structure
    assert 'assessment-header' in result, "Should have assessment header"
    assert 'Total: 10 marks' in result, "Should show total marks"
    
    # Test default title when none provided
    html_no_title = '''
<div class="admonition freetext-assessment">
    <p class="admonition-title">Freetext Assessment</p>
    <p>question: Simple question</p>
    <p>marks: 1</p>
</div>
'''
    
    result_default = plugin.on_page_content(html_no_title, mock_page, {}, None)
    assert '<h3>Assessment</h3>' in result_default, "Should use default title 'Assessment'"


def test_assessment_total_marks_calculation():
    """Test that total marks are calculated correctly for assessments."""
    plugin = FreetextPlugin()
    plugin.load_config({})
    
    # Create mock page
    mock_file = type('MockFile', (), {'src_path': 'test.md'})()
    mock_page = type('MockPage', (), {'file': mock_file})()
    
    # Test various mark combinations
    test_cases = [
        {
            'questions': [('Q1', 5), ('Q2', 3), ('Q3', 7)],
            'expected_total': 15
        },
        {
            'questions': [('Q1', 0), ('Q2', 10)],
            'expected_total': 10
        },
        {
            'questions': [('Q1', 1)],
            'expected_total': 1
        }
    ]
    
    for i, case in enumerate(test_cases):
        # Build HTML for this test case
        questions_html = []
        for j, (question, marks) in enumerate(case['questions']):
            if j > 0:
                questions_html.append('<hr>')
            questions_html.extend([
                f'<p>question: {question}</p>',
                f'<p>marks: {marks}</p>'
            ])
        
        html_marks_test = f'''
<div class="admonition freetext-assessment">
    <p class="admonition-title">Freetext Assessment</p>
    <p>title: Test Case {i+1}</p>
    {''.join(questions_html)}
</div>
'''
        
        # Process and verify
        result = plugin.on_page_content(html_marks_test, mock_page, {}, None)
        expected_text = f'Total: {case["expected_total"]} marks'
        
        assert expected_text in result, f"Test case {i+1}: Should show '{expected_text}'"
        
        # Verify individual question marks
        for question, marks in case['questions']:
            if marks > 0:  # Only shown if > 0
                assert f'({marks} marks)' in result, f"Should show marks for {question}"


def test_assessment_vs_single_question_behavior():
    """Test that assessments behave differently from single questions."""
    plugin = FreetextPlugin()
    plugin.load_config({})
    
    # Create mock page
    mock_file = type('MockFile', (), {'src_path': 'test.md'})()
    mock_page = type('MockPage', (), {'file': mock_file})()
    
    # Single question HTML
    html_single = '''
<div class="admonition freetext">
    <p class="admonition-title">Freetext</p>
    <p>question: Single question</p>
    <p>marks: 5</p>
</div>
'''
    
    # Assessment HTML with one question
    html_assessment = '''
<div class="admonition freetext-assessment">
    <p class="admonition-title">Freetext Assessment</p>
    <p>question: Assessment question</p>
    <p>marks: 5</p>
</div>
'''
    
    # Process both
    result_single = plugin.on_page_content(html_single, mock_page, {}, None)
    plugin = FreetextPlugin()  # Reset plugin state
    plugin.load_config({})
    result_assessment = plugin.on_page_content(html_assessment, mock_page, {}, None)
    
    # Single question should NOT have:
    assert 'freetext-assessment' not in result_single, "Single question should not use assessment class"
    assert 'Submit Assessment' not in result_single, "Single question should not have assessment submit"
    assert 'Total:' not in result_single, "Single question should not show total marks"
    assert '1.' not in result_single, "Single question should not be numbered"
    
    # Assessment should have:
    assert 'freetext-assessment' in result_assessment, "Assessment should use assessment class"
    assert 'Submit Assessment' in result_assessment, "Assessment should have assessment submit"
    assert 'Total: 5 marks' in result_assessment, "Assessment should show total marks"
    assert '1.' in result_assessment, "Assessment questions should be numbered"


def test_assessment_without_questions():
    """Test handling of malformed assessment blocks with no valid questions."""
    plugin = FreetextPlugin()
    plugin.load_config({})
    
    # Create mock page
    mock_file = type('MockFile', (), {'src_path': 'test.md'})()
    mock_page = type('MockPage', (), {'file': mock_file})()
    
    # Assessment with no questions
    html_empty = '''
<div class="admonition freetext-assessment">
    <p class="admonition-title">Freetext Assessment</p>
    <p>title: Empty Assessment</p>
    <p>Some description text but no questions.</p>
</div>
'''
    
    # Process the HTML
    result = plugin.on_page_content(html_empty, mock_page, {}, None)
    
    # Should return original HTML when no valid questions found
    # The plugin should gracefully handle this case
    assert len(result) > 0, "Should return some content"
    # The exact behavior may vary - plugin might return original or empty content
