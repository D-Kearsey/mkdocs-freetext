"""
Test JavaScript functionality of the MkDocs Free-Text Plugin.

This test suite verifies:
1. Auto-save JavaScript generation and functionality
2. Character count JavaScript integration
3. Form submission handling
4. JavaScript configuration toggles
"""

import re
from mkdocs_freetext.plugin import FreetextPlugin


def test_auto_save_javascript_generation():
    """Test that auto-save JavaScript is generated when enabled."""
    plugin = FreetextPlugin()
    plugin.load_config({'enable_auto_save': True})
    
    # Create mock page
    mock_file = type('MockFile', (), {'src_path': 'test.md'})()
    mock_page = type('MockPage', (), {'file': mock_file})()
    
    html_question = '''
<div class="admonition freetext">
    <p class="admonition-title">Freetext</p>
    <p>question: Auto-save JavaScript test</p>
</div>
'''
    
    result = plugin.on_page_content(html_question, mock_page, {}, None)
    
    # Verify auto-save JavaScript elements
    assert '<script' in result, "Should include JavaScript when auto-save enabled"
    assert 'localStorage' in result, "Should use localStorage for auto-save"
    assert 'setItem' in result, "Should save to localStorage"
    assert 'getItem' in result, "Should retrieve from localStorage"
    assert 'autoSave_' in result, "Should include auto-save function name"
    
    # Check for event listeners
    assert 'addEventListener' in result or 'oninput' in result, "Should add input event listener"


def test_auto_save_javascript_disabled():
    """Test that auto-save JavaScript is disabled when enable_auto_save: false."""
    plugin = FreetextPlugin()
    plugin.load_config({'enable_auto_save': False})
    
    # Create mock page
    mock_file = type('MockFile', (), {'src_path': 'test.md'})()
    mock_page = type('MockPage', (), {'file': mock_file})()
    
    html_question = '''
<div class="admonition freetext">
    <p class="admonition-title">Freetext</p>
    <p>question: Auto-save disabled test</p>
</div>
'''
    
    result = plugin.on_page_content(html_question, mock_page, {}, None)
    
    # JavaScript may still be present but should be disabled
    if 'autoSave_' in result:
        # Check that auto-save is disabled in the condition
        assert 'if (false)' in result, "Auto-save should be disabled with false condition"
    
    # Or localStorage functions should be minimal/absent
    if 'localStorage' in result:
        # Should not actively save if disabled
        js_functions = re.findall(r'function.*?{.*?}', result, re.DOTALL)
        for func in js_functions:
            if 'autoSave' in func:
                assert 'return' in func or 'if (false)' in func, "Auto-save function should return early when disabled"


def test_character_count_javascript():
    """Test that character count JavaScript is generated when enabled."""
    plugin = FreetextPlugin()
    plugin.load_config({'show_character_count': True})
    
    # Create mock page
    mock_file = type('MockFile', (), {'src_path': 'test.md'})()
    mock_page = type('MockPage', (), {'file': mock_file})()
    
    html_question = '''
<div class="admonition freetext">
    <p class="admonition-title">Freetext</p>
    <p>question: Character count JavaScript test</p>
    <p>max_chars: 100</p>
</div>
'''
    
    result = plugin.on_page_content(html_question, mock_page, {}, None)
    
    # Verify character count JavaScript
    assert 'updateCharCount_' in result, "Should include character count update function"
    assert '.length' in result, "Should check text length"
    assert 'innerHTML' in result or 'textContent' in result, "Should update counter display"
    
    # Check for character limit handling
    assert '100' in result, "Should include the max character limit"


def test_character_count_javascript_disabled():
    """Test that character count JavaScript is not generated when disabled."""
    plugin = FreetextPlugin()
    plugin.load_config({'show_character_count': False})
    
    # Create mock page
    mock_file = type('MockFile', (), {'src_path': 'test.md'})()
    mock_page = type('MockPage', (), {'file': mock_file})()
    
    html_question = '''
<div class="admonition freetext">
    <p class="admonition-title">Freetext</p>
    <p>question: No character count test</p>
    <p>max_chars: 100</p>
</div>
'''
    
    result = plugin.on_page_content(html_question, mock_page, {}, None)
    
    # Should not include character count JavaScript
    assert 'updateCharCount_' not in result, "Should NOT include character count function when disabled"
    assert 'char-count' not in result, "Should NOT include character counter elements"


def test_unique_javascript_ids():
    """Test that JavaScript generates unique IDs for multiple questions."""
    plugin = FreetextPlugin()
    plugin.load_config({'enable_auto_save': True, 'show_character_count': True})
    
    # Create mock page
    mock_file = type('MockFile', (), {'src_path': 'test.md'})()
    mock_page = type('MockPage', (), {'file': mock_file})()
    
    html_multiple_questions = '''
<div class="admonition freetext">
    <p class="admonition-title">Freetext</p>
    <p>question: First question</p>
</div>
<div class="admonition freetext">
    <p class="admonition-title">Freetext</p>
    <p>question: Second question</p>
</div>
<div class="admonition freetext">
    <p class="admonition-title">Freetext</p>
    <p>question: Third question</p>
</div>
'''
    
    result = plugin.on_page_content(html_multiple_questions, mock_page, {}, None)
    
    # Extract all function names and IDs
    auto_save_functions = re.findall(r'autoSave_\w+', result)
    char_count_functions = re.findall(r'updateCharCount_\w+', result)
    answer_textarea_ids = re.findall(r'id="answer_\w+"', result)  # Fixed: use answer_ not textarea_
    
    # Verify that we have unique function names (no duplicate function names)
    unique_auto_save = set(auto_save_functions)
    unique_char_count = set(char_count_functions)
    unique_textarea_ids = set(answer_textarea_ids)
    
    # Each question should have a unique auto-save function name (appears in definition + calls)
    assert len(unique_auto_save) == 3, f"Should have 3 unique auto-save function names, got {len(unique_auto_save)}: {unique_auto_save}"
    # Each question should have a unique character count function name (appears in definition + calls)  
    assert len(unique_char_count) == 3, f"Should have 3 unique char count function names, got {len(unique_char_count)}: {unique_char_count}"
    # Each question should have a unique textarea ID
    assert len(unique_textarea_ids) == 3, f"Should have 3 unique textarea IDs, got {len(unique_textarea_ids)}: {unique_textarea_ids}"
    
    # Verify that functions appear multiple times (definition + calls) - this is normal JavaScript
    # Auto-save functions should appear 2 times each (definition + oninput call)
    assert len(auto_save_functions) == 6, f"Auto-save functions should appear 6 times total (2 per question), got {len(auto_save_functions)}"
    # Character count functions should appear 3 times each (definition + oninput call + DOM ready call)
    assert len(char_count_functions) == 9, f"Character count functions should appear 9 times total (3 per question), got {len(char_count_functions)}"


def test_form_submission_javascript():
    """Test JavaScript for form submission and data collection."""
    plugin = FreetextPlugin()
    plugin.load_config({})
    
    # Create mock page
    mock_file = type('MockFile', (), {'src_path': 'test.md'})()
    mock_page = type('MockPage', (), {'file': mock_file})()
    
    html_assessment = '''
<div class="admonition freetext-assessment">
    <p class="admonition-title">Freetext Assessment</p>
    <p>question: Assessment question 1</p>
    <p>marks: 5</p>
    <hr>
    <p>question: Assessment question 2</p>
    <p>marks: 3</p>
</div>
'''
    
    result = plugin.on_page_content(html_assessment, mock_page, {}, None)
    
    # Check for assessment submission JavaScript
    if '<script' in result:
        # Look for form handling
        form_keywords = ['submit', 'form', 'collect', 'answers', 'assessment']
        found_form_js = any(keyword in result.lower() for keyword in form_keywords)
        
        if found_form_js:
            assert 'function' in result, "Should include JavaScript functions for form handling"


def test_javascript_error_handling():
    """Test that JavaScript includes basic error handling."""
    plugin = FreetextPlugin()
    plugin.load_config({'enable_auto_save': True, 'show_character_count': True})
    
    # Create mock page
    mock_file = type('MockFile', (), {'src_path': 'test.md'})()
    mock_page = type('MockPage', (), {'file': mock_file})()
    
    html_question = '''
<div class="admonition freetext">
    <p class="admonition-title">Freetext</p>
    <p>question: Error handling test</p>
</div>
'''
    
    result = plugin.on_page_content(html_question, mock_page, {}, None)
    
    if '<script' in result:
        # Check for basic error handling patterns
        error_handling = [
            'try',
            'catch',
            'if (',  # Conditional checks
            '&&',    # Logical AND for safety checks
            '||',    # Logical OR for fallbacks
        ]
        
        found_error_handling = any(pattern in result for pattern in error_handling)
        assert found_error_handling, "JavaScript should include basic error handling patterns"


def test_javascript_dom_ready():
    """Test that JavaScript waits for DOM to be ready."""
    plugin = FreetextPlugin()
    plugin.load_config({'enable_auto_save': True})
    
    # Create mock page
    mock_file = type('MockFile', (), {'src_path': 'test.md'})()
    mock_page = type('MockPage', (), {'file': mock_file})()
    
    html_question = '''
<div class="admonition freetext">
    <p class="admonition-title">Freetext</p>
    <p>question: DOM ready test</p>
</div>
'''
    
    result = plugin.on_page_content(html_question, mock_page, {}, None)
    
    if '<script' in result:
        # Check for DOM ready patterns
        dom_ready_patterns = [
            'DOMContentLoaded',
            'addEventListener',
            'document.ready',
            'window.onload',
            'defer',  # Script defer attribute
        ]
        
        found_dom_ready = any(pattern in result for pattern in dom_ready_patterns)
        if 'addEventListener' in result or 'DOMContentLoaded' in result:
            assert found_dom_ready, "Should wait for DOM to be ready before executing"


def test_javascript_no_global_pollution():
    """Test that JavaScript doesn't pollute global namespace excessively."""
    plugin = FreetextPlugin()
    plugin.load_config({'enable_auto_save': True, 'show_character_count': True})
    
    # Create mock page
    mock_file = type('MockFile', (), {'src_path': 'test.md'})()
    mock_page = type('MockPage', (), {'file': mock_file})()
    
    html_question = '''
<div class="admonition freetext">
    <p class="admonition-title">Freetext</p>
    <p>question: Global namespace test</p>
</div>
'''
    
    result = plugin.on_page_content(html_question, mock_page, {}, None)
    
    if '<script' in result:
        # Count global function declarations
        global_functions = re.findall(r'function\s+(\w+)', result)
        
        # All functions should be prefixed (autoSave_, updateCharCount_, etc.)
        prefixed_functions = [f for f in global_functions if '_' in f]
        
        # Most functions should be prefixed to avoid conflicts
        if global_functions:
            prefix_ratio = len(prefixed_functions) / len(global_functions)
            assert prefix_ratio >= 0.5, "Most functions should be prefixed to avoid global namespace pollution"


def test_assessment_shuffle_javascript():
    """Test JavaScript for question shuffling in assessments."""
    plugin = FreetextPlugin()
    plugin.load_config({'shuffle_questions': True})
    
    # Create mock page
    mock_file = type('MockFile', (), {'src_path': 'test.md'})()
    mock_page = type('MockPage', (), {'file': mock_file})()
    
    html_assessment = '''
<div class="admonition freetext-assessment">
    <p class="admonition-title">Freetext Assessment</p>
    <p>question: Question 1</p>
    <p>marks: 2</p>
    <hr>
    <p>question: Question 2</p>
    <p>marks: 3</p>
    <hr>
    <p>question: Question 3</p>
    <p>marks: 4</p>
</div>
'''
    
    result = plugin.on_page_content(html_assessment, mock_page, {}, None)
    
    # Check for shuffle-related attributes and JavaScript
    assert 'data-shuffle="true"' in result, "Should include shuffle data attribute"
    
    if '<script' in result:
        # Look for shuffle-related JavaScript
        shuffle_keywords = ['shuffle', 'random', 'Math.random', 'sort']
        found_shuffle_js = any(keyword in result for keyword in shuffle_keywords)
        
        if found_shuffle_js:
            assert 'Math.random' in result or 'shuffle' in result, "Should include shuffling logic"
